export type EpisodeType = 'video' | 'notes' | 'coding' | 'quiz' | 'review';

export interface Episode {
  id: string;
  seasonId: string;
  number: number;
  title: string;
  description: string;
  type: EpisodeType;
  durationMinutes: number;
  focusMinutesRequired: number;
  youtubeUrl: string;
  thumbnail: string;
  xpReward: number;
  tags: string[];
}

export interface Season {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  topic: string;
  thumbnail: string;
  heroImage: string;
  episodes: Episode[];
  totalXP: number;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  color: string;
}

export interface StoryChapter {
  id: string;
  title: string;
  content: string;
  requiredFocusMinutes: number;
  requiredSessions: number;
  unlockType: '10min' | '30min' | '60min' | 'chapter';
}

export interface UserProgress {
  completedEpisodes: string[];
  episodeTimestamps: Record<string, number>;
  episodeNotes: Record<string, string>;
  currentSeasonId: string;
  currentEpisodeId: string | null;
  xp: number;
  level: number;
  streak: number;
  lastStudyDate: string;
  totalFocusMinutes: number;
  totalSessions: number;
  storyProgress: number;
  unlockedStoryIds: string[];
  treeGrowth: number;
  rewards: string[];
  distractionCount: number;
  customVideos: CustomVideo[];
}

export interface CustomVideo {
  id: string;
  url: string;
  title: string;
  savedTimestamp: number;
  addedAt: string;
}

export interface FocusSession {
  episodeId: string;
  startTime: number;
  elapsedSeconds: number;
  isActive: boolean;
  isPomodoroBreak: boolean;
}
