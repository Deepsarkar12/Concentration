import { useState, useEffect } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Users, ChevronRight, Youtube, X } from "lucide-react";
import { toast } from "sonner";
import { useAppStore } from "@/stores/useAppStore";
import { SEASONS } from "@/constants/seasons";
import FocusTimer from "@/components/features/FocusTimer";
import YouTubePlayer from "@/components/features/YouTubePlayer";
import NotesPanel from "@/components/features/NotesPanel";
import MilestoneTracker from "@/components/features/MilestoneTracker";
import type { Episode } from "@/types";

export default function EpisodePlayer() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { progress, markEpisodeComplete, saveTimestamp, addCustomVideo, removeCustomVideo, updateCustomVideoTimestamp, focusSession } = useAppStore();

  const isCustom = id === "custom";
  const customVidId = searchParams.get("vid");
  const customVideo = customVidId ? progress.customVideos.find((v) => v.id === customVidId) : null;

  // Find the episode
  let episode: Episode | null = null;
  let season = null;
  let episodeIndex = -1;
  if (!isCustom) {
    for (const s of SEASONS) {
      const idx = s.episodes.findIndex((e) => e.id === id);
      if (idx !== -1) {
        episode = s.episodes[idx];
        season = s;
        episodeIndex = idx;
        break;
      }
    }
  }

  const [episodeCompleted, setEpisodeCompleted] = useState(
    episode ? progress.completedEpisodes.includes(episode.id) : false
  );
  const [showAddVideo, setShowAddVideo] = useState(!customVideo && isCustom);
  const [newVideoUrl, setNewVideoUrl] = useState("");
  const [newVideoTitle, setNewVideoTitle] = useState("");

  // Milestones for sidebar
  const milestones = episode
    ? [
        { title: "Introduction", subtitle: "Completed in 0:37", status: "completed" as const },
        { title: episode.title, subtitle: "Current Active Scene", status: "active" as const },
        { title: "Practice Problems", subtitle: "Locked until session complete", status: "locked" as const },
      ]
    : [];

  const handleEpisodeComplete = () => {
    if (!episode) return;
    if (!progress.completedEpisodes.includes(episode.id)) {
      markEpisodeComplete(episode.id);
      setEpisodeCompleted(true);
      toast.success(`🎉 Episode "${episode.title}" completed! +${episode.xpReward} XP`, { duration: 5000 });

      // Auto-navigate to next episode after 3s
      if (season && episodeIndex < season.episodes.length - 1) {
        setTimeout(() => {
          const next = season!.episodes[episodeIndex + 1];
          toast.info(`▶ Auto-playing next: ${next.title}`, { duration: 3000 });
          setTimeout(() => navigate(`/player/${next.id}`), 2000);
        }, 2000);
      }
    }
  };

  const handleAddCustomVideo = () => {
    if (!newVideoUrl) return;
    addCustomVideo(newVideoUrl, newVideoTitle || "My Video");
    setShowAddVideo(false);
    toast.success("Video added! Start watching and focus timer will track your session.");
  };

  const handleRemoveCustomVideo = () => {
    if (customVidId) {
      removeCustomVideo(customVidId);
      navigate("/player/custom");
    }
  };

  if (!episode && !isCustom) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-4">
        <p className="text-gray-500">Episode not found</p>
        <button onClick={() => navigate("/")} className="text-brand-orange hover:underline">
          Back to Dashboard
        </button>
      </div>
    );
  }

  return (
    <div className="animate-fade-up">
      {/* Back nav */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors text-sm"
        >
          <ArrowLeft size={16} />
          Back to Dashboard
        </button>
        {season && (
          <>
            <ChevronRight size={14} className="text-gray-700" />
            <span className="text-gray-500 text-sm">{season.title}</span>
            <ChevronRight size={14} className="text-gray-700" />
            <span className="text-brand-orange text-sm font-medium">
              E{episode?.number}: {episode?.title}
            </span>
          </>
        )}
        {isCustom && (
          <>
            <ChevronRight size={14} className="text-gray-700" />
            <span className="text-brand-orange text-sm font-medium">
              {customVideo ? customVideo.title : "Add Custom Video"}
            </span>
          </>
        )}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main content - left */}
        <div className="lg:col-span-2 space-y-5">
          {/* Video player */}
          {isCustom ? (
            <>
              {showAddVideo || !customVideo ? (
                <div className="rounded-2xl p-6" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 rounded-xl bg-red-500/15 flex items-center justify-center">
                      <Youtube size={20} className="text-red-500" />
                    </div>
                    <div>
                      <h2 className="font-display font-bold text-white">Add YouTube Video</h2>
                      <p className="text-xs text-gray-500">Watch any coding tutorial and track your focus</p>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">YouTube URL *</label>
                      <input
                        value={newVideoUrl}
                        onChange={(e) => setNewVideoUrl(e.target.value)}
                        placeholder="https://www.youtube.com/watch?v=..."
                        className="w-full px-4 py-3 rounded-xl text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-gray-400 mb-1 block">Video Title (optional)</label>
                      <input
                        value={newVideoTitle}
                        onChange={(e) => setNewVideoTitle(e.target.value)}
                        placeholder="e.g., CS50 Week 5 - Data Structures"
                        className="w-full px-4 py-3 rounded-xl text-sm"
                      />
                    </div>
                    <button
                      onClick={handleAddCustomVideo}
                      disabled={!newVideoUrl}
                      className="w-full py-3 rounded-xl bg-brand-orange text-white font-bold text-sm hover:bg-brand-orange-dark transition-colors disabled:opacity-50"
                    >
                      Load Video & Start Session
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between mb-2">
                    <h2 className="font-display text-xl font-bold text-white">{customVideo.title}</h2>
                    <button onClick={handleRemoveCustomVideo} className="text-gray-600 hover:text-red-400 transition-colors p-1">
                      <X size={16} />
                    </button>
                  </div>
                  <YouTubePlayer
                    defaultUrl={customVideo.url}
                    savedTimestamp={customVideo.savedTimestamp}
                    onTimestampSave={(s) => updateCustomVideoTimestamp(customVideo.id, s)}
                    allowCustomUrl={false}
                  />
                </>
              )}
            </>
          ) : (
            episode && (
              <>
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <span className="text-xs text-brand-orange font-bold uppercase tracking-wide">
                      Season 1 · Episode {episode.number}
                    </span>
                    <h1 className="font-display text-2xl font-bold text-white mt-0.5">{episode.title}</h1>
                    <p className="text-sm text-gray-400 mt-1">{episode.description}</p>
                  </div>
                  {episodeCompleted && (
                    <span className="px-3 py-1.5 rounded-full bg-green-500/15 text-green-400 text-xs font-bold border border-green-500/30">
                      ✓ Completed
                    </span>
                  )}
                </div>

                {/* Tags */}
                <div className="flex gap-2 flex-wrap">
                  {episode.tags.map((tag) => (
                    <span key={tag} className="px-2 py-0.5 rounded-full text-xs bg-white/5 text-gray-400 border border-white/10">
                      {tag}
                    </span>
                  ))}
                </div>

                <YouTubePlayer
                  defaultUrl={episode.youtubeUrl}
                  savedTimestamp={progress.episodeTimestamps[episode.id] || 0}
                  onTimestampSave={(s) => saveTimestamp(episode.id, s)}
                />
              </>
            )
          )}

          {/* Notes */}
          {episode && (
            <NotesPanel episodeId={episode.id} episodeTitle={episode.title} />
          )}
          {customVideo && (
            <NotesPanel episodeId={customVideo.id} episodeTitle={customVideo.title} />
          )}

          {/* Social proof */}
          <div className="flex items-center gap-3 p-4 rounded-xl" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
            <div className="flex -space-x-2">
              {["#F97316", "#38BDF8", "#A78BFA", "#34D399"].map((c, i) => (
                <div key={i} className="w-7 h-7 rounded-full border-2 border-black flex items-center justify-center text-xs font-bold text-white"
                  style={{ background: c }}>
                  {String.fromCharCode(65 + i)}
                </div>
              ))}
            </div>
            <div className="flex items-center gap-1">
              <Users size={14} className="text-gray-500" />
              <span className="text-sm text-gray-400">
                <span className="text-white font-semibold">+{Math.floor(Math.random() * 20) + 8}</span> other students are focused with you
              </span>
            </div>
          </div>
        </div>

        {/* Sidebar - right */}
        <div className="space-y-5">
          {/* Focus Timer */}
          {episode && (
            <FocusTimer
              episodeId={episode.id}
              requiredMinutes={episode.focusMinutesRequired}
              onComplete={handleEpisodeComplete}
            />
          )}
          {(isCustom && (customVideo || showAddVideo)) && (
            <FocusTimer
              episodeId={customVideo?.id || "custom-temp"}
              requiredMinutes={10}
              onComplete={() => toast.success("Great focus session! 🎉")}
            />
          )}

          {/* Milestones */}
          {episode && (
            <MilestoneTracker
              milestones={milestones}
              unlockInSeconds={Math.max(0, (episode.focusMinutesRequired * 60) - (focusSession?.elapsedSeconds || 0))}
              requiredSeconds={episode.focusMinutesRequired * 60}
            />
          )}

          {/* Resource Vault */}
          <div className="rounded-2xl p-4" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
            <p className="text-xs font-bold uppercase tracking-widest text-gray-600 mb-3">RESOURCE VAULT</p>
            <div className="grid grid-cols-2 gap-3">
              <button className="p-3 rounded-xl text-center hover:bg-white/5 transition-colors" style={{ background: "#110800" }}>
                <div className="text-xl mb-1">{"</>"}</div>
                <span className="text-xs text-gray-400">Source Code</span>
              </button>
              <button className="p-3 rounded-xl text-center hover:bg-white/5 transition-colors" style={{ background: "#110800" }}>
                <div className="text-xl mb-1">📋</div>
                <span className="text-xs text-gray-400">Cheat Sheet</span>
              </button>
              <button className="p-3 rounded-xl text-center hover:bg-white/5 transition-colors" style={{ background: "#110800" }}>
                <div className="text-xl mb-1">🧩</div>
                <span className="text-xs text-gray-400">Practice</span>
              </button>
              <button className="p-3 rounded-xl text-center hover:bg-white/5 transition-colors" style={{ background: "#110800" }}>
                <div className="text-xl mb-1">📖</div>
                <span className="text-xs text-gray-400">References</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
