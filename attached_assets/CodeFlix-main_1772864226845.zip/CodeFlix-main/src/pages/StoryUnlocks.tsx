import { useState } from "react";
import { BookOpen, Lock, ChevronDown, ChevronUp, Clock, Zap, Star, Gift } from "lucide-react";
import { useAppStore } from "@/stores/useAppStore";
import { STORY_CHAPTERS, REWARD_MILESTONES } from "@/constants/story";

export default function StoryUnlocks() {
  const { progress } = useAppStore();
  const [expandedChapter, setExpandedChapter] = useState<string | null>(
    progress.unlockedStoryIds[progress.unlockedStoryIds.length - 1] || null
  );

  const toggleChapter = (id: string) => {
    setExpandedChapter(expandedChapter === id ? null : id);
  };

  const isUnlocked = (id: string) => progress.unlockedStoryIds.includes(id);

  return (
    <div className="animate-fade-up max-w-3xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-brand-orange/15 flex items-center justify-center">
            <BookOpen size={20} className="text-brand-orange" />
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold text-white">Story Unlocks</h1>
            <p className="text-gray-500 text-sm">Focus more → unlock more of Aria's coding adventure</p>
          </div>
        </div>

        {/* Progress stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="rounded-xl p-3 text-center" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
            <p className="text-xl font-display font-bold text-brand-orange">{progress.unlockedStoryIds.length}</p>
            <p className="text-xs text-gray-500">Chapters Unlocked</p>
          </div>
          <div className="rounded-xl p-3 text-center" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
            <p className="text-xl font-display font-bold text-white">{progress.totalFocusMinutes}</p>
            <p className="text-xs text-gray-500">Focus Minutes</p>
          </div>
          <div className="rounded-xl p-3 text-center" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
            <p className="text-xl font-display font-bold text-white">{progress.totalSessions}</p>
            <p className="text-xs text-gray-500">Sessions</p>
          </div>
        </div>

        {/* Master progress */}
        <div className="rounded-xl p-4" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
          <div className="flex justify-between mb-2">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wide">Story Progress</span>
            <span className="text-xs text-brand-orange font-bold">
              {progress.unlockedStoryIds.length}/{STORY_CHAPTERS.length} chapters
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-black/50">
            <div
              className="h-full rounded-full progress-bar transition-all duration-700"
              style={{ width: `${(progress.unlockedStoryIds.length / STORY_CHAPTERS.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Story chapters */}
      <div className="space-y-4 mb-8">
        <h2 className="font-display text-xl font-bold text-white">The Algorithm Chronicles</h2>
        <p className="text-sm text-gray-500 italic">A cyberpunk story about a programmer named Aria who discovers the sentient Algorithm...</p>

        {STORY_CHAPTERS.map((chapter, i) => {
          const unlocked = isUnlocked(chapter.id);
          const isExpanded = expandedChapter === chapter.id;
          const isNext = !unlocked && (i === 0 || isUnlocked(STORY_CHAPTERS[i - 1].id));

          return (
            <div
              key={chapter.id}
              className={`rounded-2xl overflow-hidden transition-all duration-300 ${unlocked ? "cursor-pointer" : ""}`}
              style={{
                background: unlocked ? "#1C1008" : "#110800",
                border: `1px solid ${unlocked ? "#3D2510" : "#1A0E06"}`,
                opacity: unlocked ? 1 : 0.7,
              }}
            >
              <button
                className={`w-full p-5 text-left flex items-center gap-4 ${unlocked ? "hover:bg-white/3" : ""} transition-colors`}
                onClick={() => unlocked && toggleChapter(chapter.id)}
                disabled={!unlocked}
              >
                {/* Chapter number */}
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 font-display font-bold text-lg
                    ${unlocked ? "bg-brand-orange/20 text-brand-orange" : "bg-gray-800 text-gray-600"}
                  `}
                >
                  {i + 1}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className={`font-display font-semibold text-sm ${unlocked ? "text-white" : "text-gray-600"}`}>
                      {chapter.title}
                    </h3>
                    {isNext && !unlocked && (
                      <span className="px-2 py-0.5 rounded-full text-xs bg-brand-orange/15 text-brand-orange font-bold border border-brand-orange/20">
                        NEXT
                      </span>
                    )}
                  </div>

                  {unlocked ? (
                    <p className={`text-xs leading-relaxed ${isExpanded ? "text-gray-400" : "text-gray-600"} line-clamp-1`}>
                      {chapter.content.substring(0, 80)}...
                    </p>
                  ) : (
                    <div className="flex items-center gap-3 text-xs text-gray-700">
                      <span className="flex items-center gap-1">
                        <Clock size={11} />
                        {chapter.requiredFocusMinutes} focus min
                      </span>
                      <span className="flex items-center gap-1">
                        <Zap size={11} />
                        {chapter.requiredSessions} sessions
                      </span>
                    </div>
                  )}
                </div>

                {/* Status icon */}
                <div className="flex-shrink-0">
                  {unlocked ? (
                    isExpanded ? <ChevronUp size={18} className="text-brand-orange" /> : <ChevronDown size={18} className="text-gray-500" />
                  ) : (
                    <Lock size={18} className={isNext ? "text-brand-orange/50" : "text-gray-700"} />
                  )}
                </div>
              </button>

              {/* Expanded content */}
              {unlocked && isExpanded && (
                <div className="px-5 pb-5">
                  <div className="pt-4 border-t" style={{ borderColor: "#2A1500" }}>
                    <p className="text-sm text-gray-300 leading-relaxed italic font-serif">
                      {chapter.content}
                    </p>
                    <div className="mt-4 flex items-center gap-2">
                      <Star size={12} className="text-brand-gold" />
                      <span className="text-xs text-gray-600">Chapter unlocked by {chapter.requiredFocusMinutes} minutes of focus</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Locked next progress */}
              {isNext && !unlocked && (
                <div className="px-5 pb-4">
                  <div className="p-3 rounded-xl" style={{ background: "#0A0500", border: "1px solid #1C1008" }}>
                    <p className="text-xs text-gray-600 mb-1.5">Your progress toward this unlock:</p>
                    <div className="flex gap-4 text-xs mb-2">
                      <span>
                        Focus: <span className="text-brand-orange font-bold">{progress.totalFocusMinutes}/{chapter.requiredFocusMinutes} min</span>
                      </span>
                      <span>
                        Sessions: <span className="text-brand-orange font-bold">{progress.totalSessions}/{chapter.requiredSessions}</span>
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-gray-900">
                      <div
                        className="h-full rounded-full progress-bar"
                        style={{
                          width: `${Math.min(100, Math.min(
                            (progress.totalFocusMinutes / chapter.requiredFocusMinutes) * 100,
                            (progress.totalSessions / chapter.requiredSessions) * 100
                          ))}%`
                        }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Rewards section */}
      <div>
        <h2 className="font-display text-xl font-bold text-white mb-4 flex items-center gap-2">
          <Gift size={20} className="text-brand-gold" />
          Entertainment Rewards
        </h2>
        <div className="space-y-3">
          {REWARD_MILESTONES.map((milestone) => {
            const earned = progress.rewards.includes(milestone.id);
            const isNextReward = !earned && !REWARD_MILESTONES.slice(0, REWARD_MILESTONES.indexOf(milestone)).some(m => !progress.rewards.includes(m.id));

            return (
              <div
                key={milestone.id}
                className="flex items-center gap-4 p-4 rounded-xl"
                style={{
                  background: earned ? "#1C1A08" : "#1C1008",
                  border: `1px solid ${earned ? "#3D3510" : "#2A1500"}`,
                }}
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl flex-shrink-0
                    ${earned ? "bg-brand-gold/20" : "bg-gray-800/50"}
                  `}
                >
                  {earned ? "🎉" : "🔒"}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-semibold ${earned ? "text-white" : "text-gray-500"}`}>
                    {milestone.reward}
                  </p>
                  <p className="text-xs text-gray-600 mt-0.5">Complete {milestone.sessions} sessions</p>
                  {!earned && (
                    <div className="flex items-center gap-2 mt-1.5">
                      <div className="flex-1 h-1 rounded-full bg-gray-800">
                        <div
                          className="h-full rounded-full progress-bar"
                          style={{ width: `${Math.min(100, (progress.totalSessions / milestone.sessions) * 100)}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-600">{progress.totalSessions}/{milestone.sessions}</span>
                    </div>
                  )}
                </div>
                {earned && (
                  <div className="px-3 py-1.5 rounded-full bg-brand-gold/20 border border-brand-gold/30">
                    <span className="text-xs font-bold text-brand-gold">EARNED!</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
