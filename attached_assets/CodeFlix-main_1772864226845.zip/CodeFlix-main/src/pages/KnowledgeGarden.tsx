import { Leaf, Droplets, Sun, Flame, Zap, Trophy, TrendingUp, Calendar } from "lucide-react";
import { useAppStore } from "@/stores/useAppStore";
import { SEASONS, getLevelInfo } from "@/constants/seasons";
import TreeVisualization from "@/components/features/TreeVisualization";
import knowledgeTree from "@/assets/knowledge-tree.jpg";

export default function KnowledgeGarden() {
  const { progress } = useAppStore();
  const { current, next, progress: lvlProgress } = getLevelInfo(progress.xp);

  const totalEpisodes = SEASONS.reduce((sum, s) => sum + s.episodes.length, 0);
  const completionPct = Math.round((progress.completedEpisodes.length / totalEpisodes) * 100);

  // Weekly activity mock
  const today = new Date();
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() - (6 - i));
    const isStudied = i < (progress.streak || 0) || (progress.totalSessions > 0 && i === 6);
    return {
      label: d.toLocaleDateString("en", { weekday: "short" }),
      active: isStudied,
      minutes: isStudied ? Math.floor(Math.random() * 30 + 10) : 0,
    };
  });

  return (
    <div className="animate-fade-up max-w-5xl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-green-500/15 flex items-center justify-center">
            <Leaf size={20} className="text-green-400" />
          </div>
          <div>
            <h1 className="font-display text-3xl font-bold text-white">Knowledge Garden</h1>
            <p className="text-gray-500 text-sm">Your learning journey visualized as a living tree</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6 mb-6">
        {/* Tree */}
        <TreeVisualization />

        {/* Level & XP */}
        <div className="space-y-4">
          {/* Level card */}
          <div className="rounded-2xl p-6" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-widest">Current Level</p>
                <h2 className="font-display text-4xl font-bold text-brand-orange">{current.level}</h2>
                <p className="text-lg font-semibold text-white">{current.title}</p>
              </div>
              <div className="w-20 h-20 rounded-full bg-brand-orange/15 border-2 border-brand-orange/30 flex items-center justify-center">
                <Trophy size={32} className="text-brand-gold" />
              </div>
            </div>

            {/* XP bar */}
            <div className="mb-2">
              <div className="flex justify-between text-xs text-gray-500 mb-1">
                <span>{progress.xp} XP</span>
                <span>{next.minXP} XP → {next.title}</span>
              </div>
              <div className="w-full h-3 rounded-full bg-black/50">
                <div
                  className="h-full rounded-full progress-bar transition-all duration-700"
                  style={{ width: `${lvlProgress}%` }}
                />
              </div>
            </div>
            <p className="text-xs text-gray-600">{next.minXP - progress.xp} XP until next level</p>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-xl p-4 text-center" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
              <Flame size={20} className="text-brand-orange mx-auto mb-2" />
              <p className="text-2xl font-display font-bold text-white">{progress.streak}</p>
              <p className="text-xs text-gray-500">Day Streak</p>
            </div>
            <div className="rounded-xl p-4 text-center" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
              <Sun size={20} className="text-brand-gold mx-auto mb-2" />
              <p className="text-2xl font-display font-bold text-white">{progress.totalFocusMinutes}</p>
              <p className="text-xs text-gray-500">Focus Minutes</p>
            </div>
            <div className="rounded-xl p-4 text-center" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
              <Zap size={20} className="text-brand-teal-glow mx-auto mb-2" />
              <p className="text-2xl font-display font-bold text-white">{progress.totalSessions}</p>
              <p className="text-xs text-gray-500">Sessions Done</p>
            </div>
            <div className="rounded-xl p-4 text-center" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
              <TrendingUp size={20} className="text-green-400 mx-auto mb-2" />
              <p className="text-2xl font-display font-bold text-white">{completionPct}%</p>
              <p className="text-xs text-gray-500">Course Done</p>
            </div>
          </div>
        </div>
      </div>

      {/* Weekly activity */}
      <div className="rounded-2xl p-6 mb-6" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
        <div className="flex items-center gap-2 mb-5">
          <Calendar size={16} className="text-brand-orange" />
          <h3 className="font-display font-semibold text-white">Weekly Activity</h3>
          <span className="ml-auto text-xs text-gray-500">Last 7 days</span>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {days.map((day, i) => (
            <div key={i} className="flex flex-col items-center gap-2">
              <div
                className={`w-full rounded-lg transition-all duration-500 flex items-end justify-center`}
                style={{
                  height: "80px",
                  background: day.active ? "#1A0900" : "#110800",
                  border: `1px solid ${day.active ? "#3D2510" : "#1C1008"}`,
                }}
              >
                {day.active && (
                  <div
                    className="w-full rounded-lg progress-bar transition-all duration-700"
                    style={{ height: `${Math.min(100, (day.minutes / 40) * 100)}%`, minHeight: "20%" }}
                  />
                )}
              </div>
              <span className={`text-xs ${day.active ? "text-brand-orange font-bold" : "text-gray-700"}`}>
                {day.label}
              </span>
              {day.active && (
                <span className="text-xs text-gray-600">{day.minutes}m</span>
              )}
            </div>
          ))}
        </div>

        {progress.streak === 0 && (
          <div className="mt-4 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
            <p className="text-xs text-yellow-500 text-center">⚠️ No streak yet! Complete a focus session today to start growing your tree.</p>
          </div>
        )}
      </div>

      {/* Season completion map */}
      <div className="rounded-2xl p-6" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
        <h3 className="font-display font-semibold text-white mb-4">Season Progress Map</h3>
        <div className="space-y-4">
          {SEASONS.map((season) => {
            const completed = season.episodes.filter((e) => progress.completedEpisodes.includes(e.id)).length;
            const pct = Math.round((completed / season.episodes.length) * 100);
            return (
              <div key={season.id}>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg overflow-hidden flex-shrink-0">
                      <img src={season.thumbnail} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">{season.topic}</p>
                      <p className="text-xs text-gray-600">{season.difficulty} · {completed}/{season.episodes.length} episodes</p>
                    </div>
                  </div>
                  <span className="text-sm font-bold" style={{ color: season.color }}>{pct}%</span>
                </div>
                <div className="w-full h-2 rounded-full bg-black/50">
                  <div
                    className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${pct}%`, background: season.color, boxShadow: `0 0 8px ${season.color}66` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
