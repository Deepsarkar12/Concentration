import { useState } from "react";
import { ChevronLeft, ChevronRight, Flame, Zap, Clock, BookOpen, Gift, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAppStore } from "@/stores/useAppStore";
import { SEASONS, getLevelInfo } from "@/constants/seasons";
import { STORY_CHAPTERS, REWARD_MILESTONES } from "@/constants/story";
import SeasonHero from "@/components/features/SeasonHero";
import EpisodeCard from "@/components/features/EpisodeCard";
import TreeVisualization from "@/components/features/TreeVisualization";

export default function Dashboard() {
  const { progress, activeSeasonId, setActiveSeasonId } = useAppStore();
  const navigate = useNavigate();
  const [episodeScrollRef, setEpisodeScrollRef] = useState<HTMLDivElement | null>(null);

  const activeSeason = SEASONS.find((s) => s.id === activeSeasonId) || SEASONS[0];
  const { current, next, progress: lvlProgress } = getLevelInfo(progress.xp);

  const scrollEpisodes = (dir: "left" | "right") => {
    if (!episodeScrollRef) return;
    episodeScrollRef.scrollBy({ left: dir === "left" ? -280 : 280, behavior: "smooth" });
  };

  const isEpisodeLocked = (index: number) => {
    if (index === 0) return false;
    const prevEpisode = activeSeason.episodes[index - 1];
    return !progress.completedEpisodes.includes(prevEpisode.id);
  };

  const isCurrentEpisode = (index: number) => {
    if (index === 0 && !progress.completedEpisodes.includes(activeSeason.episodes[0].id)) return true;
    return (
      !isEpisodeLocked(index) &&
      !progress.completedEpisodes.includes(activeSeason.episodes[index].id) &&
      (index === 0 || progress.completedEpisodes.includes(activeSeason.episodes[index - 1].id))
    );
  };

  const unlockedStoryCount = progress.unlockedStoryIds.length;
  const nextStory = STORY_CHAPTERS.find((ch) => !progress.unlockedStoryIds.includes(ch.id));
  const earnedRewards = REWARD_MILESTONES.filter((r) => progress.rewards.includes(r.id));

  return (
    <div className="animate-fade-up space-y-8">
      {/* Stats bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
          <div className="w-10 h-10 rounded-lg bg-orange-500/15 flex items-center justify-center">
            <Flame size={20} className="text-brand-orange" />
          </div>
          <div>
            <p className="text-xs text-gray-500">Streak</p>
            <p className="text-xl font-display font-bold text-white">{progress.streak} <span className="text-sm text-gray-500">days</span></p>
          </div>
        </div>
        <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
          <div className="w-10 h-10 rounded-lg bg-yellow-500/15 flex items-center justify-center">
            <Zap size={20} className="text-brand-gold" />
          </div>
          <div>
            <p className="text-xs text-gray-500">Total XP</p>
            <p className="text-xl font-display font-bold text-white">{progress.xp}</p>
          </div>
        </div>
        <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
          <div className="w-10 h-10 rounded-lg bg-blue-500/15 flex items-center justify-center">
            <Clock size={20} className="text-blue-400" />
          </div>
          <div>
            <p className="text-xs text-gray-500">Focus Time</p>
            <p className="text-xl font-display font-bold text-white">{progress.totalFocusMinutes} <span className="text-sm text-gray-500">min</span></p>
          </div>
        </div>
        <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
          <div className="w-10 h-10 rounded-lg bg-green-500/15 flex items-center justify-center">
            <BookOpen size={20} className="text-green-400" />
          </div>
          <div>
            <p className="text-xs text-gray-500">Episodes Done</p>
            <p className="text-xl font-display font-bold text-white">{progress.completedEpisodes.length}</p>
          </div>
        </div>
      </div>

      {/* Level progress bar */}
      <div className="rounded-xl p-4" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
        <div className="flex items-center justify-between mb-2">
          <div>
            <span className="text-sm font-bold text-brand-orange">LVL {current.level} — {current.title}</span>
            <span className="text-xs text-gray-600 ml-2">→ {next.title} at {next.minXP} XP</span>
          </div>
          <span className="text-xs text-gray-500">{progress.xp} / {next.minXP} XP</span>
        </div>
        <div className="w-full h-2 rounded-full bg-black/50">
          <div
            className="h-full rounded-full progress-bar transition-all duration-700"
            style={{ width: `${lvlProgress}%` }}
          />
        </div>
      </div>

      {/* Hero Season */}
      <SeasonHero season={activeSeason} />

      {/* Episodes row */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-display text-xl font-bold text-white">Episodes</h2>
            <span className="text-sm text-gray-500">{activeSeason.title}</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => scrollEpisodes("left")}
              className="w-8 h-8 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors"
              style={{ background: "#1C1008", border: "1px solid #2A1500" }}
            >
              <ChevronLeft size={16} />
            </button>
            <button
              onClick={() => scrollEpisodes("right")}
              className="w-8 h-8 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors"
              style={{ background: "#1C1008", border: "1px solid #2A1500" }}
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>

        <div
          ref={setEpisodeScrollRef}
          className="flex gap-4 overflow-x-auto pb-3"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {activeSeason.episodes.map((episode, i) => (
            <EpisodeCard
              key={episode.id}
              episode={episode}
              isCompleted={progress.completedEpisodes.includes(episode.id)}
              isLocked={isEpisodeLocked(i)}
              isCurrent={isCurrentEpisode(i)}
              savedTimestamp={progress.episodeTimestamps[episode.id]}
            />
          ))}
        </div>
      </div>

      {/* Bottom grid: Recommended + Story + Tree */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recommended series */}
        <div className="lg:col-span-2">
          <h2 className="font-display text-xl font-bold text-white mb-4">Recommended Series</h2>
          <div className="grid grid-cols-2 sm:grid-cols-2 gap-3">
            {SEASONS.filter((s) => s.id !== activeSeasonId).slice(0, 4).map((season) => {
              const completedCount = season.episodes.filter((e) => progress.completedEpisodes.includes(e.id)).length;
              const pct = Math.round((completedCount / season.episodes.length) * 100);
              return (
                <button
                  key={season.id}
                  onClick={() => setActiveSeasonId(season.id)}
                  className="relative rounded-xl overflow-hidden text-left hover:scale-102 transition-transform duration-200 active:scale-100 group"
                  style={{ aspectRatio: "16/9" }}
                >
                  <img src={season.thumbnail} alt={season.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.85) 0%, transparent 60%)" }} />
                  <div className="absolute bottom-0 left-0 right-0 p-3">
                    <p className="text-sm font-bold text-white leading-tight">{season.topic}</p>
                    <p className="text-xs text-gray-400">{season.subtitle} · {pct}% done</p>
                    <div className="w-full h-0.5 bg-white/20 rounded mt-1">
                      <div className="h-full progress-bar rounded" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Story + Rewards sidebar */}
        <div className="space-y-4">
          {/* Story Preview */}
          <div className="rounded-xl p-4 story-gradient" style={{ border: "1px solid #2A1500" }}>
            <div className="flex items-center gap-2 mb-3">
              <BookOpen size={16} className="text-brand-orange" />
              <h3 className="font-display font-semibold text-white text-sm">Story Unlocks</h3>
              <span className="ml-auto text-xs bg-brand-orange/20 text-brand-orange px-2 py-0.5 rounded-full">
                {unlockedStoryCount}/{STORY_CHAPTERS.length}
              </span>
            </div>
            {unlockedStoryCount > 0 ? (
              <div>
                <p className="text-xs text-gray-400 mb-2 italic leading-relaxed line-clamp-3">
                  "{STORY_CHAPTERS[unlockedStoryCount - 1].content.substring(0, 120)}..."
                </p>
                <button
                  onClick={() => navigate("/story")}
                  className="text-xs text-brand-orange hover:underline font-medium"
                >
                  Read full story →
                </button>
              </div>
            ) : (
              <p className="text-xs text-gray-600">Focus for 10 minutes to unlock the first story chapter!</p>
            )}
            {nextStory && (
              <div className="mt-3 p-2 rounded-lg" style={{ background: "#110800", border: "1px solid #2A1500" }}>
                <p className="text-xs text-gray-500">Next unlock at</p>
                <p className="text-xs font-bold text-brand-gold">{nextStory.requiredFocusMinutes} focus min · {nextStory.requiredSessions} sessions</p>
              </div>
            )}
          </div>

          {/* Rewards */}
          <div className="rounded-xl p-4" style={{ background: "#1C1008", border: "1px solid #2A1500" }}>
            <div className="flex items-center gap-2 mb-3">
              <Gift size={16} className="text-brand-gold" />
              <h3 className="font-display font-semibold text-white text-sm">Rewards Earned</h3>
            </div>
            {earnedRewards.length > 0 ? (
              <div className="space-y-2">
                {earnedRewards.slice(-2).map((r) => {
                  const milestone = REWARD_MILESTONES.find((m) => m.id === r.id);
                  return milestone ? (
                    <div key={r.id} className="p-2 rounded-lg text-xs" style={{ background: "#110800" }}>
                      {milestone.reward}
                    </div>
                  ) : null;
                })}
              </div>
            ) : (
              <p className="text-xs text-gray-600">Complete 10 sessions to earn your first reward!</p>
            )}
            <div className="mt-2 p-2 rounded-lg" style={{ background: "#110800" }}>
              <p className="text-xs text-gray-600">Next reward at <span className="text-brand-orange font-bold">
                {REWARD_MILESTONES.find((r) => !progress.rewards.includes(r.id))?.sessions || "∞"} sessions
              </span></p>
            </div>
          </div>

          {/* Tree mini preview */}
          <button
            onClick={() => navigate("/garden")}
            className="w-full rounded-xl overflow-hidden relative hover:scale-102 transition-transform"
            style={{ border: "1px solid #2A1500" }}
          >
            <TreeVisualization />
          </button>
        </div>
      </div>

      {/* Custom Videos section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl font-bold text-white">My Custom Videos</h2>
          <button
            onClick={() => navigate("/player/custom")}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-orange/15 text-brand-orange text-sm font-medium hover:bg-brand-orange/25 transition-colors"
          >
            <Plus size={14} />
            Add YouTube Video
          </button>
        </div>
        {progress.customVideos.length === 0 ? (
          <div className="rounded-xl p-8 text-center" style={{ background: "#1C1008", border: "2px dashed #2A1500" }}>
            <p className="text-gray-600 text-sm mb-2">No custom videos yet</p>
            <p className="text-gray-700 text-xs">Paste any YouTube URL to watch and track your progress</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {progress.customVideos.map((v) => (
              <button
                key={v.id}
                onClick={() => navigate(`/player/custom?vid=${v.id}`)}
                className="p-4 rounded-xl text-left hover:bg-white/5 transition-colors"
                style={{ background: "#1C1008", border: "1px solid #2A1500" }}
              >
                <p className="text-sm font-semibold text-white mb-1 truncate">{v.title}</p>
                <p className="text-xs text-gray-500 truncate">{v.url}</p>
                {v.savedTimestamp > 0 && (
                  <span className="inline-block mt-2 text-xs text-brand-orange">
                    Resume at {Math.floor(v.savedTimestamp / 60)}:{(v.savedTimestamp % 60).toString().padStart(2, "0")}
                  </span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
