import { useState } from "react";
import { Settings as SettingsIcon, Bell, Eye, Clock, RotateCcw, Shield, Palette, AlertTriangle } from "lucide-react";
import { useAppStore } from "@/stores/useAppStore";
import { toast } from "sonner";
import { getLevelInfo } from "@/constants/seasons";

export default function Settings() {
  const { progress, resetProgress } = useAppStore();
  const { current } = getLevelInfo(progress.xp);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [pomodoroWork, setPomodoroWork] = useState(15);
  const [pomodoroBreak, setPomodoroBreak] = useState(3);
  const [notifications, setNotifications] = useState(true);
  const [distractionAlert, setDistractionAlert] = useState(true);

  const handleReset = () => {
    resetProgress();
    setShowResetConfirm(false);
    toast.success("Progress reset. Start fresh! 🌱");
  };

  const handleSaveSettings = () => {
    toast.success("Settings saved!");
  };

  return (
    <div className="animate-fade-up max-w-2xl">
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-gray-500/15 flex items-center justify-center">
          <SettingsIcon size={20} className="text-gray-400" />
        </div>
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Settings</h1>
          <p className="text-gray-500 text-sm">Customize your CodeFlix experience</p>
        </div>
      </div>

      {/* Profile */}
      <div className="rounded-2xl p-6 mb-4" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
        <h2 className="font-display font-semibold text-white mb-4 flex items-center gap-2">
          <Shield size={16} className="text-brand-orange" />
          Your Profile
        </h2>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-2xl bg-brand-orange/20 border-2 border-brand-orange/40 flex items-center justify-center text-brand-orange text-2xl font-bold">
            A
          </div>
          <div>
            <p className="text-white font-semibold">Code Explorer</p>
            <p className="text-sm text-brand-orange">Level {current.level} · {current.title}</p>
            <p className="text-xs text-gray-600 mt-0.5">{progress.xp} XP total · {progress.streak} day streak</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-gray-500 block mb-1">Display Name</label>
            <input
              defaultValue="Code Explorer"
              className="w-full px-3 py-2 rounded-lg text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-gray-500 block mb-1">Daily Goal (minutes)</label>
            <input
              type="number"
              defaultValue={30}
              className="w-full px-3 py-2 rounded-lg text-sm"
              min={5}
              max={240}
            />
          </div>
        </div>
      </div>

      {/* Focus Timer Settings */}
      <div className="rounded-2xl p-6 mb-4" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
        <h2 className="font-display font-semibold text-white mb-4 flex items-center gap-2">
          <Clock size={16} className="text-brand-orange" />
          Focus Timer
        </h2>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="text-xs text-gray-500 block mb-1">Pomodoro Work Duration (min)</label>
            <input
              type="number"
              value={pomodoroWork}
              onChange={(e) => setPomodoroWork(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg text-sm"
              min={5}
              max={60}
            />
          </div>
          <div>
            <label className="text-xs text-gray-500 block mb-1">Break Duration (min)</label>
            <input
              type="number"
              value={pomodoroBreak}
              onChange={(e) => setPomodoroBreak(Number(e.target.value))}
              className="w-full px-3 py-2 rounded-lg text-sm"
              min={1}
              max={15}
            />
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 rounded-xl" style={{ background: "#110800" }}>
            <div>
              <p className="text-sm text-white">Distraction Detection</p>
              <p className="text-xs text-gray-600">Pause timer when you switch tabs</p>
            </div>
            <button
              onClick={() => setDistractionAlert(!distractionAlert)}
              className={`w-12 h-6 rounded-full transition-all duration-300 relative flex-shrink-0
                ${distractionAlert ? "bg-brand-orange" : "bg-gray-700"}
              `}
            >
              <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all duration-300
                ${distractionAlert ? "left-6" : "left-0.5"}
              `} />
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl" style={{ background: "#110800" }}>
            <div>
              <p className="text-sm text-white">Auto-play Next Episode</p>
              <p className="text-xs text-gray-600">Automatically start the next episode on completion</p>
            </div>
            <button
              className="w-12 h-6 rounded-full bg-brand-orange relative flex-shrink-0"
            >
              <div className="absolute top-0.5 left-6 w-5 h-5 rounded-full bg-white shadow" />
            </button>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="rounded-2xl p-6 mb-4" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
        <h2 className="font-display font-semibold text-white mb-4 flex items-center gap-2">
          <Bell size={16} className="text-brand-orange" />
          Notifications
        </h2>
        <div className="space-y-3">
          {[
            { label: "Daily streak reminder", desc: "Get reminded to keep your streak alive", enabled: notifications },
            { label: "Story chapter unlocked", desc: "Notification when you unlock a new story chapter", enabled: true },
            { label: "Reward earned", desc: "Celebrate when you earn an entertainment reward", enabled: true },
            { label: "Level up alert", desc: "Know when you level up your account", enabled: true },
          ].map((n, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-xl" style={{ background: "#110800" }}>
              <div>
                <p className="text-sm text-white">{n.label}</p>
                <p className="text-xs text-gray-600">{n.desc}</p>
              </div>
              <button
                className={`w-12 h-6 rounded-full transition-all duration-300 relative flex-shrink-0
                  ${n.enabled ? "bg-brand-orange" : "bg-gray-700"}
                `}
                onClick={() => setNotifications(!n.enabled)}
              >
                <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all duration-300
                  ${n.enabled ? "left-6" : "left-0.5"}
                `} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Appearance */}
      <div className="rounded-2xl p-6 mb-4" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
        <h2 className="font-display font-semibold text-white mb-4 flex items-center gap-2">
          <Palette size={16} className="text-brand-orange" />
          Appearance
        </h2>
        <div>
          <label className="text-xs text-gray-500 block mb-2">Accent Color</label>
          <div className="flex gap-3">
            {["#F97316", "#3B82F6", "#A78BFA", "#34D399", "#F59E0B", "#EF4444"].map((color) => (
              <button
                key={color}
                className={`w-8 h-8 rounded-full transition-transform hover:scale-110 ${color === "#F97316" ? "ring-2 ring-white ring-offset-2 ring-offset-black" : ""}`}
                style={{ background: color }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Save */}
      <button
        onClick={handleSaveSettings}
        className="w-full py-3 rounded-xl bg-brand-orange text-white font-bold text-sm hover:bg-brand-orange-dark transition-colors mb-4 glow-orange-sm"
      >
        Save Settings
      </button>

      {/* Danger zone */}
      <div className="rounded-2xl p-6" style={{ background: "#1C0808", border: "1px solid #3D1010" }}>
        <h2 className="font-display font-semibold text-red-400 mb-3 flex items-center gap-2">
          <AlertTriangle size={16} />
          Danger Zone
        </h2>
        <p className="text-xs text-gray-600 mb-4">Reset all progress, XP, streaks, and story unlocks. This cannot be undone.</p>

        {!showResetConfirm ? (
          <button
            onClick={() => setShowResetConfirm(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500/10 text-red-400 text-sm font-medium border border-red-500/20 hover:bg-red-500/20 transition-colors"
          >
            <RotateCcw size={14} />
            Reset All Progress
          </button>
        ) : (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
            <p className="text-sm text-red-300 mb-3 font-medium">Are you absolutely sure? This will delete all your progress!</p>
            <div className="flex gap-3">
              <button onClick={handleReset} className="px-4 py-2 rounded-lg bg-red-500 text-white text-sm font-bold hover:bg-red-600 transition-colors">
                Yes, Reset Everything
              </button>
              <button onClick={() => setShowResetConfirm(false)} className="px-4 py-2 rounded-lg text-gray-400 text-sm hover:text-white transition-colors" style={{ background: "#1C1008" }}>
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
