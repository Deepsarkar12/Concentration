import { useNavigate } from "react-router-dom";
import { Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center gap-6">
      <div className="text-8xl font-display font-bold text-brand-orange opacity-20">404</div>
      <div>
        <h1 className="font-display text-2xl font-bold text-white mb-2">Episode Not Found</h1>
        <p className="text-gray-500 text-sm">This episode doesn't exist or may have been moved.</p>
      </div>
      <div className="flex gap-3">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-gray-400 hover:text-white transition-colors"
          style={{ background: "#1C1008", border: "1px solid #2A1500" }}
        >
          <ArrowLeft size={16} />
          Go Back
        </button>
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-brand-orange text-white font-medium hover:bg-brand-orange-dark transition-colors"
        >
          <Home size={16} />
          Dashboard
        </button>
      </div>
    </div>
  );
}
