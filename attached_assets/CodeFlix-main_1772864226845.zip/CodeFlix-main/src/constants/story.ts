import type { StoryChapter } from "@/types";

export const STORY_CHAPTERS: StoryChapter[] = [
  {
    id: "ch1-p1",
    title: "The Algorithm Awakens",
    content:
      "In the city of Byteville, a young programmer named Aria booted her ancient terminal for the first time. Lines of green code scrolled across the screen — each character a step toward a hidden truth. She had heard the legends: somewhere in the digital depths lived the Algorithm, a sentient pattern that could solve any problem ever conceived by human minds...",
    requiredFocusMinutes: 10,
    requiredSessions: 1,
    unlockType: "10min",
  },
  {
    id: "ch1-p2",
    title: "The First Pointer",
    content:
      "The next morning, Aria discovered a pointer — not of memory, but of fate. Scrawled in the margin of her DSA textbook was a coordinate: 0x7FFE. She followed it through Byteville's neon-lit corridors to a hidden library where every shelf held a different data structure. The librarian, an old man named Node, smiled. 'You've come for the Array Tome,' he whispered. 'Few survive the recursion...'",
    requiredFocusMinutes: 30,
    requiredSessions: 3,
    unlockType: "30min",
  },
  {
    id: "ch1-p3",
    title: "The Stack Rises",
    content:
      "Deep in Node's library, Aria pushed her fears onto a mental stack and popped them one by one. Each solved problem revealed another. The linked list of clues stretched forward into darkness. Then she saw it — a glowing BST, its branches pulsing with orange light. 'This is the heart of the Algorithm,' Node said. 'But to reach the root, you must first traverse every leaf...'",
    requiredFocusMinutes: 60,
    requiredSessions: 6,
    unlockType: "60min",
  },
  {
    id: "ch2-p1",
    title: "Graph of Connections",
    content:
      "Season 2 of Aria's journey began at the Graph Bazaar — a marketplace where every vendor was a node and every transaction an edge. Weighted paths led to cheaper secrets. Dijkstra's ghost haunted the alleys, whispering optimal routes. Aria mapped the entire bazaar in her notebook, connecting the dots between the Algorithm's scattered fragments...",
    requiredFocusMinutes: 90,
    requiredSessions: 9,
    unlockType: "chapter",
  },
  {
    id: "ch2-p2",
    title: "The Hash Collision",
    content:
      "Two keys hashed to the same slot. Aria watched, fascinated, as Byteville's twin skyscrapers — Binary Tower and Linear Tower — phased into each other. The collision created a temporal rift. She had 15 minutes — one Pomodoro cycle — to find the rehashing formula before the universe segfaulted. Her fingers flew across the keyboard...",
    requiredFocusMinutes: 120,
    requiredSessions: 12,
    unlockType: "chapter",
  },
  {
    id: "ch3-p1",
    title: "The O(1) Secret",
    content:
      "At the peak of Mount Complexity, the Algorithm finally spoke to Aria. 'Every problem has an O(1) solution if you know the right data structure,' it said. 'But the true complexity is not in the code — it is in the courage to keep running when every test case fails.' Aria looked at her streak counter. 30 days. The tree behind her had grown taller than any building in Byteville...",
    requiredFocusMinutes: 180,
    requiredSessions: 18,
    unlockType: "chapter",
  },
];

export const REWARD_MILESTONES = [
  { sessions: 10, reward: "🎬 Watch one movie episode guilt-free!", id: "r1" },
  { sessions: 25, reward: "🎮 1 hour of gaming — you've earned it!", id: "r2" },
  { sessions: 50, reward: "🍕 Treat yourself to your favorite meal!", id: "r3" },
  { sessions: 75, reward: "📺 Binge 3 episodes of your favorite series!", id: "r4" },
  { sessions: 100, reward: "🎉 Full day off — you're a legend!", id: "r5" },
];
