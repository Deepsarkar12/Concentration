import type { UserProgress } from "@/types";

const STORAGE_KEY = "codeflix_progress";

export const DEFAULT_PROGRESS: UserProgress = {
  completedEpisodes: [],
  episodeTimestamps: {},
  episodeNotes: {},
  currentSeasonId: "dsa-s1",
  currentEpisodeId: null,
  xp: 0,
  level: 1,
  streak: 0,
  lastStudyDate: "",
  totalFocusMinutes: 0,
  totalSessions: 0,
  storyProgress: 0,
  unlockedStoryIds: [],
  treeGrowth: 0,
  rewards: [],
  distractionCount: 0,
  customVideos: [],
};

export function loadProgress(): UserProgress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_PROGRESS };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_PROGRESS, ...parsed };
  } catch {
    return { ...DEFAULT_PROGRESS };
  }
}

export function saveProgress(progress: UserProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    console.error("Failed to save progress");
  }
}

export function updateStreak(progress: UserProgress): UserProgress {
  const today = new Date().toDateString();
  const yesterday = new Date(Date.now() - 86400000).toDateString();

  if (progress.lastStudyDate === today) {
    return progress;
  } else if (progress.lastStudyDate === yesterday) {
    return { ...progress, streak: progress.streak + 1, lastStudyDate: today };
  } else if (progress.lastStudyDate === "") {
    return { ...progress, streak: 1, lastStudyDate: today };
  } else {
    return { ...progress, streak: 1, lastStudyDate: today };
  }
}

export function addXP(progress: UserProgress, amount: number): UserProgress {
  const newXP = progress.xp + amount;
  return { ...progress, xp: newXP };
}

export function completeEpisode(progress: UserProgress, episodeId: string, xpReward: number, focusMinutes: number): UserProgress {
  if (progress.completedEpisodes.includes(episodeId)) return progress;
  const updated = {
    ...progress,
    completedEpisodes: [...progress.completedEpisodes, episodeId],
    xp: progress.xp + xpReward,
    totalFocusMinutes: progress.totalFocusMinutes + focusMinutes,
    totalSessions: progress.totalSessions + 1,
    treeGrowth: Math.min(100, progress.treeGrowth + 8),
    storyProgress: progress.storyProgress + focusMinutes,
  };
  return updateStreak(updated);
}

export function extractYoutubeId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}
