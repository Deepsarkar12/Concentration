import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "sonner";
import Sidebar from "@/components/layout/Sidebar";
import Header from "@/components/layout/Header";
import Dashboard from "@/pages/Dashboard";
import EpisodePlayer from "@/pages/EpisodePlayer";
import KnowledgeGarden from "@/pages/KnowledgeGarden";
import StoryUnlocks from "@/pages/StoryUnlocks";
import Settings from "@/pages/Settings";
import NotFound from "@/pages/NotFound";
import { useAppStore } from "@/stores/useAppStore";

function AppLayout({ children }: { children: React.ReactNode }) {
  const { sidebarOpen } = useAppStore();

  return (
    <div className="min-h-screen" style={{ background: "#0F0800" }}>
      <Sidebar />
      <Header />
      <main
        className="transition-all duration-300 pt-14 min-h-screen"
        style={{ marginLeft: sidebarOpen ? "224px" : "64px" }}
      >
        <div className="p-6 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: "#1C1008",
            border: "1px solid #3D2510",
            color: "#f5e6d0",
          },
        }}
      />
      <Routes>
        <Route
          path="/"
          element={
            <AppLayout>
              <Dashboard />
            </AppLayout>
          }
        />
        <Route
          path="/player/:id"
          element={
            <AppLayout>
              <EpisodePlayer />
            </AppLayout>
          }
        />
        <Route
          path="/garden"
          element={
            <AppLayout>
              <KnowledgeGarden />
            </AppLayout>
          }
        />
        <Route
          path="/story"
          element={
            <AppLayout>
              <StoryUnlocks />
            </AppLayout>
          }
        />
        <Route
          path="/settings"
          element={
            <AppLayout>
              <Settings />
            </AppLayout>
          }
        />
        <Route path="*" element={<AppLayout><NotFound /></AppLayout>} />
      </Routes>
    </BrowserRouter>
  );
}
