import { Lock, CheckCircle, Zap } from "lucide-react";

interface Milestone {
  title: string;
  subtitle: string;
  status: "completed" | "active" | "locked";
  unlockIn?: string;
  progress?: number;
}

interface MilestoneTrackerProps {
  milestones: Milestone[];
  unlockInSeconds?: number;
  requiredSeconds?: number;
}

export default function MilestoneTracker({ milestones, unlockInSeconds = 0, requiredSeconds = 1 }: MilestoneTrackerProps) {
  return (
    <div className="rounded-2xl p-5" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
      <div className="flex items-center gap-2 mb-4">
        <Zap size={16} className="text-brand-orange" />
        <h3 className="font-display font-semibold text-white text-sm">Episode Milestones</h3>
      </div>

      <div className="space-y-4">
        {milestones.map((m, i) => (
          <div key={i} className="flex gap-3 items-start">
            {/* Indicator */}
            <div className="flex flex-col items-center mt-0.5">
              <div className={`w-3 h-3 rounded-full flex-shrink-0 transition-colors ${
                m.status === "completed" ? "bg-brand-orange" :
                m.status === "active" ? "bg-brand-orange/60 ring-2 ring-brand-orange/30" : "bg-gray-700"
              }`} />
              {i < milestones.length - 1 && (
                <div className={`w-0.5 h-8 mt-1 ${m.status === "completed" ? "bg-brand-orange/30" : "bg-gray-800"}`} />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0 -mt-0.5">
              <div className="flex items-center justify-between gap-2">
                <p className={`text-sm font-semibold leading-tight ${
                  m.status === "active" ? "text-brand-orange" :
                  m.status === "completed" ? "text-white" : "text-gray-500"
                }`}>
                  {m.title}
                </p>
                {m.status === "completed" && <CheckCircle size={14} className="text-brand-orange flex-shrink-0" />}
                {m.status === "locked" && <Lock size={13} className="text-gray-600 flex-shrink-0" />}
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{m.subtitle}</p>

              {/* Active milestone progress */}
              {m.status === "active" && unlockInSeconds > 0 && (
                <div className="mt-2 p-2 rounded-lg" style={{ background: "#110800", border: "1px solid #2A1500" }}>
                  <p className="text-xs text-brand-orange mb-1">
                    Unlock Next Scene in {Math.floor(unlockInSeconds / 60)}:{(unlockInSeconds % 60).toString().padStart(2, "0")}
                  </p>
                  <div className="w-full h-1 rounded-full bg-gray-800">
                    <div
                      className="h-full rounded-full progress-bar transition-all duration-500"
                      style={{ width: `${Math.min(100, ((requiredSeconds - unlockInSeconds) / requiredSeconds) * 100)}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
