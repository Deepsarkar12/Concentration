import { Play, Lock, CheckCircle, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Episode } from "@/types";

interface EpisodeCardProps {
  episode: Episode;
  isCompleted: boolean;
  isLocked: boolean;
  isCurrent: boolean;
  savedTimestamp?: number;
}

export default function EpisodeCard({
  episode,
  isCompleted,
  isLocked,
  isCurrent,
  savedTimestamp,
}: EpisodeCardProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    if (!isLocked) {
      navigate(`/player/${episode.id}`);
    }
  };

  const getStatusLabel = () => {
    if (isCompleted) return "Completed";
    if (savedTimestamp && savedTimestamp > 0) {
      const mins = Math.floor(savedTimestamp / 60);
      const secs = savedTimestamp % 60;
      return `Resume at ${mins}:${secs.toString().padStart(2, "0")}`;
    }
    if (isLocked) return `Locked`;
    return `${episode.durationMinutes} mins`;
  };

  return (
    <div
      className={`episode-card relative flex-shrink-0 w-56 rounded-xl overflow-hidden cursor-pointer transition-transform duration-200 hover:scale-105
        ${isLocked ? "opacity-60 cursor-not-allowed" : ""}
        ${isCurrent ? "ring-2 ring-brand-orange glow-orange" : ""}
      `}
      onClick={handleClick}
    >
      {/* Thumbnail */}
      <div className="relative aspect-video">
        <img
          src={episode.thumbnail}
          alt={episode.title}
          className="w-full h-full object-cover"
          loading="lazy"
        />

        {/* Overlay */}
        <div className="episode-overlay absolute inset-0 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.5)" }}>
          {!isLocked && !isCompleted && (
            <div className="w-12 h-12 rounded-full bg-brand-orange flex items-center justify-center glow-orange">
              <Play size={20} className="text-white ml-0.5" />
            </div>
          )}
        </div>

        {/* Status badge */}
        {isCompleted && (
          <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-green-500 flex items-center justify-center">
            <CheckCircle size={14} className="text-white" />
          </div>
        )}
        {isLocked && (
          <div className="locked-overlay absolute inset-0 flex items-center justify-center rounded-xl">
            <Lock size={24} className="text-gray-400" />
          </div>
        )}
        {isCurrent && !isCompleted && (
          <div className="absolute top-2 left-2">
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-brand-orange text-white">
              CURRENT
            </span>
          </div>
        )}

        {/* Progress bar for current */}
        {savedTimestamp && savedTimestamp > 0 && !isCompleted && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-800">
            <div
              className="h-full progress-bar"
              style={{ width: `${Math.min(100, (savedTimestamp / (episode.durationMinutes * 60)) * 100)}%` }}
            />
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-3" style={{ background: "#1C1008" }}>
        <div className="flex items-center gap-1 mb-1">
          <span className={`text-xs font-bold ${isCurrent ? "text-brand-orange" : "text-gray-500"}`}>
            E{episode.number}
          </span>
          <span className="text-xs text-gray-600">•</span>
          <span className="text-xs text-gray-500">{episode.type}</span>
        </div>
        <p className={`text-sm font-semibold leading-tight mb-1 ${isCurrent ? "text-brand-orange" : isLocked ? "text-gray-500" : "text-white"}`}>
          {episode.title}
        </p>
        <div className="flex items-center gap-1">
          <Clock size={11} className="text-gray-600" />
          <span className="text-xs text-gray-500">{getStatusLabel()}</span>
        </div>
        <div className="flex items-center gap-1 mt-1">
          <span className="text-xs text-brand-gold font-medium">+{episode.xpReward} XP</span>
        </div>
      </div>
    </div>
  );
}
