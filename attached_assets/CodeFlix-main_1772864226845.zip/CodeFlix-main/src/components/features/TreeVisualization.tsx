import knowledgeTree from "@/assets/knowledge-tree.jpg";
import { useAppStore } from "@/stores/useAppStore";
import { Leaf, Droplets, Sun, Zap } from "lucide-react";

export default function TreeVisualization() {
  const { progress } = useAppStore();
  const growth = progress.treeGrowth;

  const stage =
    growth < 10 ? "Seed" :
    growth < 25 ? "Sprout" :
    growth < 50 ? "Sapling" :
    growth < 75 ? "Young Tree" :
    growth < 90 ? "Mature Tree" :
    "Ancient Tree";

  const stageColor =
    growth < 10 ? "#6B7280" :
    growth < 25 ? "#86EFAC" :
    growth < 50 ? "#4ADE80" :
    growth < 75 ? "#22C55E" :
    growth < 90 ? "#15803D" :
    "#F97316";

  const leafCount = Math.floor(growth / 8);

  return (
    <div className="rounded-2xl overflow-hidden relative" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
      {/* Tree image with growth overlay */}
      <div className="relative h-64">
        <img
          src={knowledgeTree}
          alt="Knowledge Tree"
          className="w-full h-full object-cover"
          style={{ filter: growth < 5 ? "grayscale(90%) brightness(0.3)" : `grayscale(${Math.max(0, 60 - growth)}%) brightness(${0.4 + growth * 0.006})` }}
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, #1C1008 0%, transparent 50%)" }} />

        {/* Stage badge */}
        <div className="absolute top-3 right-3">
          <span
            className="px-3 py-1 rounded-full text-xs font-bold"
            style={{ background: `${stageColor}22`, color: stageColor, border: `1px solid ${stageColor}44` }}
          >
            {stage}
          </span>
        </div>

        {/* Leaf count */}
        <div className="absolute top-3 left-3 flex items-center gap-1 px-2 py-1 rounded-full" style={{ background: "rgba(0,0,0,0.5)" }}>
          <Leaf size={12} className="text-green-400" />
          <span className="text-xs text-green-400 font-bold">{leafCount} leaves</span>
        </div>
      </div>

      {/* Stats */}
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display font-bold text-white">Knowledge Garden</h3>
          <span className="text-2xl font-display font-bold text-brand-orange">{growth}%</span>
        </div>

        {/* Growth bar */}
        <div className="w-full h-3 rounded-full bg-black/50 mb-4">
          <div
            className="h-full rounded-full transition-all duration-1000"
            style={{
              width: `${growth}%`,
              background: `linear-gradient(90deg, #15803D, #4ADE80, ${stageColor})`,
              boxShadow: `0 0 12px ${stageColor}66`,
            }}
          />
        </div>

        {/* Growth stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="text-center p-3 rounded-xl" style={{ background: "#110800" }}>
            <Droplets size={16} className="text-blue-400 mx-auto mb-1" />
            <p className="text-xs text-gray-500">Sessions</p>
            <p className="text-sm font-bold text-white">{progress.totalSessions}</p>
          </div>
          <div className="text-center p-3 rounded-xl" style={{ background: "#110800" }}>
            <Sun size={16} className="text-brand-gold mx-auto mb-1" />
            <p className="text-xs text-gray-500">Focus Min</p>
            <p className="text-sm font-bold text-white">{progress.totalFocusMinutes}</p>
          </div>
          <div className="text-center p-3 rounded-xl" style={{ background: "#110800" }}>
            <Zap size={16} className="text-brand-orange mx-auto mb-1" />
            <p className="text-xs text-gray-500">Streak</p>
            <p className="text-sm font-bold text-white">{progress.streak} days</p>
          </div>
        </div>

        {/* Status message */}
        <div className="mt-4 p-3 rounded-xl text-center" style={{ background: "#110800", border: "1px solid #2A1500" }}>
          {growth === 0 ? (
            <p className="text-xs text-gray-500">Complete your first focus session to grow your tree 🌱</p>
          ) : progress.streak === 0 ? (
            <p className="text-xs text-yellow-500">⚠️ Your tree is dormant. Study today to resume growth!</p>
          ) : (
            <p className="text-xs text-green-400">🌳 Your tree is thriving! Keep your {progress.streak}-day streak going!</p>
          )}
        </div>
      </div>
    </div>
  );
}
