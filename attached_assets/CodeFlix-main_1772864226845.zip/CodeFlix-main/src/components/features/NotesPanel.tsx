import { useState, useCallback } from "react";
import { FileText, Save, Plus, Hash } from "lucide-react";
import { useAppStore } from "@/stores/useAppStore";
import { toast } from "sonner";

interface NotesPanelProps {
  episodeId: string;
  episodeTitle: string;
}

export default function NotesPanel({ episodeId, episodeTitle }: NotesPanelProps) {
  const { progress, saveNotes } = useAppStore();
  const [notes, setNotes] = useState(progress.episodeNotes[episodeId] || "");
  const [saved, setSaved] = useState(false);

  const handleSave = useCallback(() => {
    saveNotes(episodeId, notes);
    setSaved(true);
    toast.success("Notes saved!");
    setTimeout(() => setSaved(false), 2000);
  }, [episodeId, notes, saveNotes]);

  const addTimestampTag = () => {
    const now = new Date();
    const tag = `[${now.toLocaleTimeString()}] `;
    setNotes((prev) => prev + "\n" + tag);
  };

  const wordCount = notes.trim() ? notes.trim().split(/\s+/).length : 0;

  return (
    <div className="rounded-2xl p-5" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <FileText size={18} className="text-brand-orange" />
          <h3 className="font-display font-semibold text-white text-sm">Interactive Lesson Notes</h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-600">{wordCount} words</span>
          <button
            onClick={addTimestampTag}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-gray-300 hover:text-white transition-colors"
            style={{ background: "#110800", border: "1px solid #2A1500" }}
          >
            <Plus size={12} />
            Timestamp
          </button>
          <button
            onClick={handleSave}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-all duration-200
              ${saved ? "bg-green-500 text-white" : "bg-brand-orange text-white hover:bg-brand-orange-dark"}
            `}
          >
            <Save size={12} />
            {saved ? "Saved!" : "Save Draft"}
          </button>
        </div>
      </div>

      {/* Textarea */}
      <textarea
        value={notes}
        onChange={(e) => { setNotes(e.target.value); setSaved(false); }}
        placeholder={`Type your notes for "${episodeTitle}" here... Use '#' to link topics, '@' to mention concepts.`}
        rows={6}
        className="w-full rounded-xl p-4 text-sm leading-relaxed resize-none font-sans"
        style={{
          background: "#110800",
          border: "1px solid #2A1500",
          color: "#e5d0b5",
        }}
      />

      {/* Tips */}
      <div className="mt-3 flex items-center gap-4">
        <div className="flex items-center gap-1">
          <Hash size={11} className="text-brand-orange" />
          <span className="text-xs text-gray-600"># to link topics</span>
        </div>
        <span className="text-xs text-gray-600">• Write 3 key insights per episode</span>
        <span className="text-xs text-gray-600">• Use timestamps to mark key moments</span>
      </div>
    </div>
  );
}
