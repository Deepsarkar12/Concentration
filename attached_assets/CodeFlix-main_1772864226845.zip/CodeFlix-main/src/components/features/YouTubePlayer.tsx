import { useState } from "react";
import { Youtube, Clock, Bookmark } from "lucide-react";
import { extractYoutubeId } from "@/lib/storage";
import { toast } from "sonner";

interface YouTubePlayerProps {
  defaultUrl?: string;
  savedTimestamp?: number;
  onTimestampSave?: (seconds: number) => void;
  allowCustomUrl?: boolean;
}

export default function YouTubePlayer({
  defaultUrl,
  savedTimestamp = 0,
  onTimestampSave,
  allowCustomUrl = false,
}: YouTubePlayerProps) {
  const [inputUrl, setInputUrl] = useState(defaultUrl || "");
  const [activeUrl, setActiveUrl] = useState(defaultUrl || "");
  const [manualTimestamp, setManualTimestamp] = useState(savedTimestamp);
  const [showInput, setShowInput] = useState(!defaultUrl && allowCustomUrl);

  const videoId = extractYoutubeId(activeUrl);
  const embedUrl = videoId
    ? `https://www.youtube-nocookie.com/embed/${videoId}?start=${savedTimestamp}&rel=0&modestbranding=1&autoplay=0`
    : null;

  const handleLoad = () => {
    const id = extractYoutubeId(inputUrl);
    if (!id) {
      toast.error("Invalid YouTube URL. Please try again.");
      return;
    }
    setActiveUrl(inputUrl);
    setShowInput(false);
    toast.success("Video loaded! Click play to start watching.");
  };

  const handleSaveTimestamp = () => {
    if (onTimestampSave) {
      onTimestampSave(manualTimestamp);
      toast.success(`Timestamp saved at ${Math.floor(manualTimestamp / 60)}:${(manualTimestamp % 60).toString().padStart(2, "0")}`);
    }
  };

  return (
    <div className="rounded-2xl overflow-hidden" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
      {/* Custom URL input */}
      {allowCustomUrl && (
        <div className="p-3 border-b" style={{ borderColor: "#2A1500" }}>
          {showInput ? (
            <div className="flex gap-2">
              <div className="flex-1 flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: "#110800", border: "1px solid #3D2510" }}>
                <Youtube size={16} className="text-red-500 flex-shrink-0" />
                <input
                  value={inputUrl}
                  onChange={(e) => setInputUrl(e.target.value)}
                  placeholder="Paste YouTube URL here..."
                  className="flex-1 bg-transparent text-sm border-none outline-none"
                  onKeyDown={(e) => e.key === "Enter" && handleLoad()}
                />
              </div>
              <button
                onClick={handleLoad}
                className="px-4 py-2 rounded-lg bg-brand-orange text-white text-sm font-bold hover:bg-brand-orange-dark transition-colors"
              >
                Load
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowInput(true)}
              className="flex items-center gap-2 text-sm text-gray-400 hover:text-brand-orange transition-colors"
            >
              <Youtube size={16} className="text-red-500" />
              <span className="truncate max-w-xs">{activeUrl || "Paste a YouTube URL to watch"}</span>
            </button>
          )}
        </div>
      )}

      {/* Player */}
      <div className="relative bg-black" style={{ paddingTop: "56.25%" }}>
        {embedUrl ? (
          <iframe
            src={embedUrl}
            className="absolute inset-0 w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="YouTube Video Player"
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4" style={{ background: "#0A0500" }}>
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: "#1C1008", border: "2px solid #3D2510" }}>
              <Youtube size={28} className="text-red-500" />
            </div>
            <div className="text-center">
              <p className="text-gray-400 text-sm font-medium mb-1">No video loaded</p>
              {allowCustomUrl && (
                <button
                  onClick={() => setShowInput(true)}
                  className="text-brand-orange text-sm hover:underline"
                >
                  Paste a YouTube link to watch
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Timestamp controls */}
      {videoId && onTimestampSave && (
        <div className="p-3 flex items-center gap-3" style={{ borderTop: "1px solid #2A1500" }}>
          <Clock size={14} className="text-gray-500 flex-shrink-0" />
          <div className="flex items-center gap-2 flex-1">
            <span className="text-xs text-gray-500">Save at:</span>
            <input
              type="number"
              value={manualTimestamp}
              onChange={(e) => setManualTimestamp(Number(e.target.value))}
              className="w-20 px-2 py-1 rounded text-xs"
              min={0}
              placeholder="seconds"
            />
            <span className="text-xs text-gray-600">
              ({Math.floor(manualTimestamp / 60)}:{(manualTimestamp % 60).toString().padStart(2, "0")})
            </span>
          </div>
          <button
            onClick={handleSaveTimestamp}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold bg-brand-orange/15 text-brand-orange hover:bg-brand-orange/25 transition-colors"
          >
            <Bookmark size={12} />
            Save
          </button>
        </div>
      )}
    </div>
  );
}
