import { Play, Info } from "lucide-react";
import { useNavigate } from "react-router-dom";
import type { Season } from "@/types";
import { useAppStore } from "@/stores/useAppStore";

interface SeasonHeroProps {
  season: Season;
}

export default function SeasonHero({ season }: SeasonHeroProps) {
  const navigate = useNavigate();
  const { progress } = useAppStore();

  const completedCount = season.episodes.filter((e) =>
    progress.completedEpisodes.includes(e.id)
  ).length;

  const progressPct = Math.round((completedCount / season.episodes.length) * 100);

  // Find current episode to play
  const firstUnlocked = season.episodes.find(
    (e) => !progress.completedEpisodes.includes(e.id)
  );
  const nextEpisode = firstUnlocked || season.episodes[season.episodes.length - 1];

  const handleContinue = () => {
    navigate(`/player/${nextEpisode.id}`);
  };

  const difficultyColors: Record<string, string> = {
    Beginner: "#22C55E",
    Intermediate: "#FBBF24",
    Advanced: "#EF4444",
  };

  return (
    <div className="relative w-full rounded-2xl overflow-hidden" style={{ minHeight: "340px" }}>
      {/* Background image */}
      <img
        src={season.heroImage}
        alt={season.title}
        className="absolute inset-0 w-full h-full object-cover"
      />

      {/* Gradient overlay */}
      <div className="hero-gradient absolute inset-0" />
      <div className="hero-gradient-bottom absolute inset-0" />

      {/* Content */}
      <div className="relative z-10 p-8 flex flex-col justify-end h-full min-h-[340px]">
        <div className="flex items-center gap-2 mb-3">
          <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-brand-orange text-white uppercase tracking-wide">
            TRENDING
          </span>
          <span className="text-sm text-gray-300">
            S1:E{completedCount + 1} Next Up
          </span>
          <span
            className="px-2 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide"
            style={{ background: `${difficultyColors[season.difficulty]}22`, color: difficultyColors[season.difficulty], border: `1px solid ${difficultyColors[season.difficulty]}44` }}
          >
            {season.difficulty}
          </span>
        </div>

        <h1 className="font-display text-4xl font-bold text-white mb-2 leading-tight">
          {season.title}
        </h1>
        <p className="text-gray-300 max-w-xl mb-6 text-sm leading-relaxed">
          {season.description}
        </p>

        <div className="flex items-center gap-3 mb-5">
          <button
            onClick={handleContinue}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-brand-orange text-white font-bold text-sm hover:bg-brand-orange-dark transition-all duration-200 glow-orange active:scale-95"
          >
            <Play size={16} className="ml-0.5" />
            {completedCount === 0 ? "Start Watching" : "Continue Watching"}
          </button>
          <button className="flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-sm text-white transition-all duration-200 hover:bg-white/10 active:scale-95" style={{ background: "rgba(255,255,255,0.12)" }}>
            <Info size={16} />
            Details
          </button>
        </div>

        {/* Progress */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold uppercase tracking-widest text-gray-400">SEASON PROGRESS</span>
            <span className="text-sm font-bold text-brand-orange">{progressPct}%</span>
          </div>
          <div className="w-full h-1.5 rounded-full bg-white/10 max-w-xs">
            <div
              className="h-full rounded-full progress-bar transition-all duration-700"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <p className="text-xs text-gray-500 mt-1">{completedCount} / {season.episodes.length} episodes complete</p>
        </div>
      </div>
    </div>
  );
}
