import { useState, useEffect, useRef, useCallback } from "react";
import { Play, Pause, RotateCcw, Coffee, AlertTriangle } from "lucide-react";
import { useAppStore } from "@/stores/useAppStore";
import { toast } from "sonner";

interface FocusTimerProps {
  episodeId: string;
  requiredMinutes: number;
  onComplete: () => void;
}

const POMODORO_WORK = 15 * 60; // 15 min in seconds
const POMODORO_BREAK = 3 * 60; // 3 min break

export default function FocusTimer({ episodeId, requiredMinutes, onComplete }: FocusTimerProps) {
  const { focusSession, startFocusSession, endFocusSession, updateFocusElapsed } = useAppStore();
  const [elapsed, setElapsed] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isPomodoroMode, setIsPomodoroMode] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [pomodoroTime, setPomodoroTime] = useState(POMODORO_WORK);
  const [completed, setCompleted] = useState(false);
  const [distracted, setDistracted] = useState(false);
  const intervalRef = useRef<number | null>(null);
  const requiredSeconds = requiredMinutes * 60;

  // Tab visibility detection
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden && isRunning && !completed) {
        setIsRunning(false);
        setDistracted(true);
        toast.error("⚠️ Distraction detected! Timer paused. Stay focused!", {
          duration: 5000,
        });
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);
    return () => document.removeEventListener("visibilitychange", handleVisibility);
  }, [isRunning, completed]);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = window.setInterval(() => {
        if (isPomodoroMode) {
          setPomodoroTime((prev) => {
            if (prev <= 1) {
              if (!isBreak) {
                setIsBreak(true);
                setPomodoroTime(POMODORO_BREAK);
                toast.success("🎉 Pomodoro complete! Take a 3-minute break.", { duration: 4000 });
              } else {
                setIsBreak(false);
                setPomodoroTime(POMODORO_WORK);
                toast.info("⚡ Break over! Back to focus mode.", { duration: 3000 });
              }
              return isBreak ? POMODORO_WORK : POMODORO_BREAK;
            }
            return prev - 1;
          });
        }
        setElapsed((prev) => {
          const next = prev + 1;
          updateFocusElapsed(next);
          if (next >= requiredSeconds && !completed) {
            setCompleted(true);
            setIsRunning(false);
            toast.success("🏆 Focus session complete! You can now mark the episode done!", {
              duration: 6000,
            });
          }
          return next;
        });
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isRunning, isPomodoroMode, isBreak, requiredSeconds, completed, updateFocusElapsed]);

  const handleStart = () => {
    if (!focusSession) startFocusSession(episodeId);
    setIsRunning(true);
    setDistracted(false);
  };

  const handlePause = () => setIsRunning(false);

  const handleReset = () => {
    setIsRunning(false);
    setElapsed(0);
    setPomodoroTime(POMODORO_WORK);
    setIsBreak(false);
    setCompleted(false);
    setDistracted(false);
  };

  const handleMarkComplete = () => {
    if (completed) {
      endFocusSession(true);
      onComplete();
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  // Circular progress
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const displayTime = isPomodoroMode ? pomodoroTime : requiredSeconds - elapsed;
  const totalTime = isPomodoroMode ? (isBreak ? POMODORO_BREAK : POMODORO_WORK) : requiredSeconds;
  const progress = isPomodoroMode
    ? ((totalTime - pomodoroTime) / totalTime) * circumference
    : (elapsed / requiredSeconds) * circumference;

  const ringColor = distracted ? "#EF4444" : isBreak ? "#38BDF8" : completed ? "#22C55E" : "#F97316";

  return (
    <div className="rounded-2xl p-5 flex flex-col items-center" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
      <div className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-1">FOCUS SESSION</div>
      <div className="text-xs text-brand-orange mb-4">
        {distracted ? "⚠️ Distraction Detected" : isBreak ? "☕ Break Time" : completed ? "✅ Complete!" : "Deep Work Mode Active"}
      </div>

      {/* Timer ring */}
      <div className="relative w-32 h-32 mb-4">
        <svg width="128" height="128" className="timer-ring absolute inset-0">
          <circle cx="64" cy="64" r={radius} fill="none" stroke="#2A1500" strokeWidth="8" />
          <circle
            cx="64"
            cy="64"
            r={radius}
            fill="none"
            stroke={ringColor}
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - progress}
            strokeLinecap="round"
            style={{ transition: "stroke-dashoffset 0.5s ease, stroke 0.3s ease", filter: `drop-shadow(0 0 8px ${ringColor}66)` }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-display text-3xl font-bold text-white">
            {isPomodoroMode ? formatTime(pomodoroTime) : formatTime(Math.max(0, displayTime))}
          </span>
          <span className="text-xs text-gray-500">
            {isPomodoroMode ? (isBreak ? "BREAK" : "FOCUS") : "LEFT"}
          </span>
        </div>
      </div>

      {/* Stats row */}
      <div className="flex gap-3 w-full mb-4">
        <div className="flex-1 rounded-xl p-3 text-center" style={{ background: "#110800" }}>
          <div className="text-xs text-gray-500 mb-0.5">Elapsed</div>
          <div className="text-sm font-bold text-white">{formatTime(elapsed)}</div>
        </div>
        <div className="flex-1 rounded-xl p-3 text-center" style={{ background: "#110800" }}>
          <div className="text-xs text-gray-500 mb-0.5">Required</div>
          <div className="text-sm font-bold text-brand-orange">{requiredMinutes}:00</div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2 mb-4">
        <button
          onClick={handleReset}
          className="w-10 h-10 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          style={{ background: "#110800" }}
          title="Reset"
        >
          <RotateCcw size={16} />
        </button>
        <button
          onClick={isRunning ? handlePause : handleStart}
          className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-200 active:scale-95
            ${distracted ? "bg-red-500" : "bg-brand-orange hover:bg-brand-orange-dark glow-orange"}
          `}
        >
          {isRunning ? (
            <Pause size={22} className="text-white" />
          ) : (
            <Play size={22} className="text-white ml-0.5" />
          )}
        </button>
        <button
          onClick={() => setIsPomodoroMode(!isPomodoroMode)}
          className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors
            ${isPomodoroMode ? "bg-blue-500/20 text-blue-400" : "text-gray-400 hover:text-white"}`}
          style={{ background: isPomodoroMode ? undefined : "#110800" }}
          title="Pomodoro Mode"
        >
          <Coffee size={16} />
        </button>
      </div>

      {isPomodoroMode && (
        <p className="text-xs text-gray-600 mb-3 text-center">Pomodoro: 15 min focus / 3 min break</p>
      )}

      {distracted && (
        <div className="flex items-center gap-2 p-2 rounded-lg mb-3 bg-red-500/10 border border-red-500/30">
          <AlertTriangle size={14} className="text-red-400" />
          <p className="text-xs text-red-400">Tab left! Restart to continue.</p>
        </div>
      )}

      {/* Mark Complete */}
      <button
        onClick={handleMarkComplete}
        disabled={!completed}
        className={`w-full py-3 rounded-xl text-sm font-bold transition-all duration-300
          ${completed
            ? "bg-green-500 text-white hover:bg-green-600 glow-orange active:scale-95"
            : "text-gray-600 cursor-not-allowed"
          }`}
        style={{ background: completed ? undefined : "#1A0E06", border: completed ? undefined : "1px solid #2A1500" }}
      >
        {completed ? "✓ Mark Episode as Complete" : `Focus ${requiredMinutes} min to unlock`}
      </button>
    </div>
  );
}
