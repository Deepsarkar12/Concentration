import { NavLink, useLocation } from "react-router-dom";
import { Tv2, BookOpen, Leaf, Settings, ChevronLeft, ChevronRight, Zap, Star } from "lucide-react";
import { useAppStore } from "@/stores/useAppStore";
import { SEASONS } from "@/constants/seasons";

const NAV_ITEMS = [
  { to: "/", label: "Seasons", icon: Tv2 },
  { to: "/story", label: "Story Unlocks", icon: BookOpen },
  { to: "/garden", label: "Knowledge Garden", icon: Leaf },
  { to: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar() {
  const { sidebarOpen, setSidebarOpen, progress, activeSeasonId, setActiveSeasonId } = useAppStore();
  const location = useLocation();

  return (
    <>
      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={`fixed top-0 left-0 h-full z-30 transition-all duration-300 flex flex-col
          ${sidebarOpen ? "w-56" : "w-16"}
        `}
        style={{ background: "#110800", borderRight: "1px solid #2A1500" }}
      >
        {/* Logo */}
        <div className={`flex items-center gap-2 px-4 py-5 ${sidebarOpen ? "" : "justify-center"}`}>
          <div className="w-8 h-8 rounded-lg bg-brand-orange flex items-center justify-center flex-shrink-0 glow-orange-sm">
            <Tv2 size={16} className="text-white" />
          </div>
          {sidebarOpen && (
            <span className="font-display font-bold text-lg text-white">
              Code<span className="text-brand-orange">Flix</span>
            </span>
          )}
        </div>

        {/* Toggle button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -right-3 top-6 w-6 h-6 rounded-full bg-brand-dark-elevated border border-brand-dark-border flex items-center justify-center hover:border-brand-orange transition-colors z-50"
        >
          {sidebarOpen ? (
            <ChevronLeft size={12} className="text-brand-orange" />
          ) : (
            <ChevronRight size={12} className="text-brand-orange" />
          )}
        </button>

        {/* Nav Items */}
        <nav className="flex-1 px-2 mt-2">
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => {
            const isActive = location.pathname === to;
            return (
              <NavLink
                key={to}
                to={to}
                className={`flex items-center gap-3 px-3 py-3 rounded-lg mb-1 transition-all duration-200 group
                  ${isActive
                    ? "bg-brand-orange/15 text-brand-orange border-l-2 border-brand-orange -ml-0.5"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                  }
                  ${!sidebarOpen ? "justify-center" : ""}
                `}
                title={!sidebarOpen ? label : undefined}
              >
                <Icon size={18} className="flex-shrink-0" />
                {sidebarOpen && <span className="text-sm font-medium">{label}</span>}
              </NavLink>
            );
          })}

          {/* Season quick-select */}
          {sidebarOpen && (
            <div className="mt-6">
              <p className="text-xs text-gray-600 uppercase tracking-widest px-3 mb-2">My Seasons</p>
              {SEASONS.map((season) => {
                const completed = season.episodes.filter((e) =>
                  progress.completedEpisodes.includes(e.id)
                ).length;
                const pct = Math.round((completed / season.episodes.length) * 100);
                return (
                  <button
                    key={season.id}
                    onClick={() => setActiveSeasonId(season.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg mb-1 transition-all duration-200 group
                      ${activeSeasonId === season.id ? "bg-white/8 text-white" : "text-gray-500 hover:text-gray-300 hover:bg-white/4"}
                    `}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium truncate">{season.subtitle}</span>
                      <span className="text-xs text-brand-orange">{pct}%</span>
                    </div>
                    <div className="w-full h-0.5 bg-white/10 rounded mt-1">
                      <div
                        className="h-full rounded progress-bar transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </nav>

        {/* Pro access / stats */}
        {sidebarOpen && (
          <div className="p-3 mx-2 mb-4 rounded-xl" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
            <div className="flex items-center gap-2 mb-2">
              <Star size={14} className="text-brand-gold" />
              <span className="text-xs font-bold text-white">PRO ACCESS</span>
            </div>
            <p className="text-xs text-gray-500 mb-3">Unlock all 50+ seasons and specialized tracks.</p>
            <button className="w-full py-2 rounded-lg bg-brand-orange text-white text-xs font-bold hover:bg-brand-orange-dark transition-colors">
              Go Pro
            </button>
          </div>
        )}
      </aside>
    </>
  );
}
