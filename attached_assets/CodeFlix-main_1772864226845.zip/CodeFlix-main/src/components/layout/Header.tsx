import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Flame, Shield, Leaf, Bell, Search, Menu, X, Zap, User } from "lucide-react";
import { useAppStore } from "@/stores/useAppStore";
import { getLevelInfo, SEASONS } from "@/constants/seasons";

export default function Header() {
  const { progress, sidebarOpen, setSidebarOpen } = useAppStore();
  const { current } = getLevelInfo(progress.xp);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  return (
    <header
      className="fixed top-0 right-0 h-14 z-20 flex items-center gap-3 px-4"
      style={{
        left: sidebarOpen ? "224px" : "64px",
        background: "rgba(15,8,0,0.92)",
        backdropFilter: "blur(12px)",
        borderBottom: "1px solid #1C1008",
        transition: "left 0.3s",
      }}
    >
      {/* Mobile menu toggle */}
      <button
        className="lg:hidden p-1.5 rounded-lg hover:bg-white/5 text-gray-400"
        onClick={() => setSidebarOpen(!sidebarOpen)}
      >
        {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
      </button>

      {/* Search */}
      <div className="flex-1 max-w-md">
        {searchOpen ? (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ background: "#1C1008", border: "1px solid #3D2510" }}>
            <Search size={14} className="text-gray-500" />
            <input
              autoFocus
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search algorithms, frameworks..."
              className="flex-1 bg-transparent text-sm text-white border-none outline-none placeholder-gray-600"
              onBlur={() => { setSearchOpen(false); setSearchQuery(""); }}
            />
          </div>
        ) : (
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-gray-500 hover:text-gray-300 transition-colors text-sm"
            style={{ background: "#1C1008", border: "1px solid #2A1500" }}
          >
            <Search size={14} />
            <span className="hidden sm:block">Search algorithms, frameworks...</span>
          </button>
        )}
      </div>

      <div className="flex items-center gap-3 ml-auto">
        {/* Streak */}
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg" style={{ background: "#1C1008" }}>
          <Flame size={16} className="text-brand-orange" />
          <span className="text-sm font-bold text-white">{progress.streak}</span>
        </div>

        {/* Level */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg" style={{ background: "#1C1008" }}>
          <Shield size={16} className="text-brand-gold" />
          <span className="text-sm font-bold text-white">LVL {current.level}</span>
          <span className="text-xs text-gray-500 hidden md:block">{current.title}</span>
        </div>

        {/* XP */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg" style={{ background: "#1C1008" }}>
          <Zap size={16} className="text-brand-teal-glow" />
          <span className="text-sm font-bold text-white">{progress.xp} XP</span>
        </div>

        {/* Garden */}
        <button
          onClick={() => navigate("/garden")}
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg hover:bg-white/5 transition-colors"
          style={{ background: "#1C1008" }}
        >
          <Leaf size={16} className="text-green-400" />
          <span className="text-sm text-gray-300">{progress.treeGrowth}%</span>
        </button>

        {/* Bell */}
        <button className="relative p-2 rounded-lg hover:bg-white/5 transition-colors text-gray-400">
          <Bell size={18} />
          {progress.rewards.length > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-brand-orange notif-pulse" />
          )}
        </button>

        {/* Avatar */}
        <div className="w-8 h-8 rounded-full bg-brand-orange/20 border-2 border-brand-orange/40 flex items-center justify-center text-brand-orange">
          <User size={16} />
        </div>
      </div>
    </header>
  );
}
