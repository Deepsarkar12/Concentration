import { create } from "zustand";
import type { UserProgress, FocusSession } from "@/types";
import { loadProgress, saveProgress, completeEpisode, addXP } from "@/lib/storage";
import { SEASONS } from "@/constants/seasons";
import { STORY_CHAPTERS, REWARD_MILESTONES } from "@/constants/story";

interface AppState {
  progress: UserProgress;
  focusSession: FocusSession | null;
  activeSeasonId: string;
  sidebarOpen: boolean;

  // Actions
  setActiveSeasonId: (id: string) => void;
  setSidebarOpen: (open: boolean) => void;
  startFocusSession: (episodeId: string) => void;
  endFocusSession: (success: boolean) => void;
  updateFocusElapsed: (seconds: number) => void;
  markEpisodeComplete: (episodeId: string) => void;
  saveTimestamp: (episodeId: string, seconds: number) => void;
  saveNotes: (episodeId: string, notes: string) => void;
  addCustomVideo: (url: string, title: string) => void;
  removeCustomVideo: (id: string) => void;
  updateCustomVideoTimestamp: (id: string, seconds: number) => void;
  checkStoryUnlocks: () => void;
  checkRewards: () => void;
  resetProgress: () => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  progress: loadProgress(),
  focusSession: null,
  activeSeasonId: loadProgress().currentSeasonId || "dsa-s1",
  sidebarOpen: true,

  setActiveSeasonId: (id) => {
    set({ activeSeasonId: id });
    const prog = get().progress;
    const updated = { ...prog, currentSeasonId: id };
    saveProgress(updated);
    set({ progress: updated });
  },

  setSidebarOpen: (open) => set({ sidebarOpen: open }),

  startFocusSession: (episodeId) => {
    set({
      focusSession: {
        episodeId,
        startTime: Date.now(),
        elapsedSeconds: 0,
        isActive: true,
        isPomodoroBreak: false,
      },
    });
  },

  endFocusSession: (success) => {
    const { focusSession, progress } = get();
    if (!focusSession) return;

    if (success) {
      const minutesFocused = Math.floor(focusSession.elapsedSeconds / 60);
      const updated = addXP(
        { ...progress, totalFocusMinutes: progress.totalFocusMinutes + minutesFocused },
        Math.floor(minutesFocused * 5)
      );
      saveProgress(updated);
      set({ progress: updated, focusSession: null });
      get().checkStoryUnlocks();
      get().checkRewards();
    } else {
      const newStreak = Math.max(0, progress.streak - 1);
      const newDistractions = progress.distractionCount + 1;
      const updated = { ...progress, streak: newStreak, distractionCount: newDistractions };
      saveProgress(updated);
      set({ progress: updated, focusSession: null });
    }
  },

  updateFocusElapsed: (seconds) => {
    set((state) => ({
      focusSession: state.focusSession
        ? { ...state.focusSession, elapsedSeconds: seconds }
        : null,
    }));
  },

  markEpisodeComplete: (episodeId) => {
    const { progress } = get();
    let episode: { xpReward: number; focusMinutesRequired: number } | null = null;
    for (const season of SEASONS) {
      const ep = season.episodes.find((e) => e.id === episodeId);
      if (ep) { episode = ep; break; }
    }
    if (!episode) return;
    const updated = completeEpisode(progress, episodeId, episode.xpReward, episode.focusMinutesRequired);
    saveProgress(updated);
    set({ progress: updated });
    get().checkStoryUnlocks();
    get().checkRewards();
  },

  saveTimestamp: (episodeId, seconds) => {
    const { progress } = get();
    const updated = {
      ...progress,
      episodeTimestamps: { ...progress.episodeTimestamps, [episodeId]: seconds },
    };
    saveProgress(updated);
    set({ progress: updated });
  },

  saveNotes: (episodeId, notes) => {
    const { progress } = get();
    const updated = {
      ...progress,
      episodeNotes: { ...progress.episodeNotes, [episodeId]: notes },
    };
    saveProgress(updated);
    set({ progress: updated });
  },

  addCustomVideo: (url, title) => {
    const { progress } = get();
    const newVideo = {
      id: `cv-${Date.now()}`,
      url,
      title: title || "My Video",
      savedTimestamp: 0,
      addedAt: new Date().toISOString(),
    };
    const updated = {
      ...progress,
      customVideos: [...progress.customVideos, newVideo],
    };
    saveProgress(updated);
    set({ progress: updated });
  },

  removeCustomVideo: (id) => {
    const { progress } = get();
    const updated = {
      ...progress,
      customVideos: progress.customVideos.filter((v) => v.id !== id),
    };
    saveProgress(updated);
    set({ progress: updated });
  },

  updateCustomVideoTimestamp: (id, seconds) => {
    const { progress } = get();
    const updated = {
      ...progress,
      customVideos: progress.customVideos.map((v) =>
        v.id === id ? { ...v, savedTimestamp: seconds } : v
      ),
    };
    saveProgress(updated);
    set({ progress: updated });
  },

  checkStoryUnlocks: () => {
    const { progress } = get();
    const newUnlocked = [...progress.unlockedStoryIds];
    for (const chapter of STORY_CHAPTERS) {
      if (
        !newUnlocked.includes(chapter.id) &&
        progress.totalFocusMinutes >= chapter.requiredFocusMinutes &&
        progress.totalSessions >= chapter.requiredSessions
      ) {
        newUnlocked.push(chapter.id);
      }
    }
    if (newUnlocked.length !== progress.unlockedStoryIds.length) {
      const updated = { ...progress, unlockedStoryIds: newUnlocked };
      saveProgress(updated);
      set({ progress: updated });
    }
  },

  checkRewards: () => {
    const { progress } = get();
    const newRewards = [...progress.rewards];
    for (const milestone of REWARD_MILESTONES) {
      if (!newRewards.includes(milestone.id) && progress.totalSessions >= milestone.sessions) {
        newRewards.push(milestone.id);
      }
    }
    if (newRewards.length !== progress.rewards.length) {
      const updated = { ...progress, rewards: newRewards };
      saveProgress(updated);
      set({ progress: updated });
    }
  },

  resetProgress: () => {
    const defaultProg = {
      completedEpisodes: [],
      episodeTimestamps: {},
      episodeNotes: {},
      currentSeasonId: "dsa-s1",
      currentEpisodeId: null,
      xp: 0,
      level: 1,
      streak: 0,
      lastStudyDate: "",
      totalFocusMinutes: 0,
      totalSessions: 0,
      storyProgress: 0,
      unlockedStoryIds: [],
      treeGrowth: 0,
      rewards: [],
      distractionCount: 0,
      customVideos: [],
    };
    saveProgress(defaultProg);
    set({ progress: defaultProg, focusSession: null });
  },
}));
